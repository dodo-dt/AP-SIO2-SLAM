<?php
// Récupérer le nom du fichier courant
$current_page = basename($_SERVER['PHP_SELF']);
?>

<nav class="navbar">
    <div class="navbar-logo">
        <img src="img/Logo.png" alt="Le Palais des Saveurs" class="logo">
    </div>

    <ul class="navbar-links">
        <li>
            <a href="index.php" class="<?= ($current_page == 'index.php') ? 'nav-active' : '' ?>">Accueil</a>
        </li>
        <li>
            <a href="menu.php" class="<?= ($current_page == 'menu.php') ? 'nav-active' : '' ?>">Menu</a>
        </li>
        <li>
            <a href="commande.php" class="<?= ($current_page == 'commande.php') ? 'nav-active highlight' : 'highlight' ?>">Commander en ligne</a>
        </li>
        <li>
            <a href="contact.php" class="<?= ($current_page == 'contact.php') ? 'nav-active' : '' ?>">Contact</a>
        </li>
    </ul>

    <!-- Logo utilisateur avec menu déroulant -->
    <div class="user-dropdown">
        <input type="checkbox" id="user-toggle" class="user-toggle">
        <label for="user-toggle" class="user-logo">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="45" height="45">
                <path fill="white" d="M16 14c-3.86 0-7-3.14-7-7s3.14-7 
                   7-7 7 3.14 7 7-3.14 7-7 
                   7zm0-12c-2.757 0-5 2.243-5 
                   5s2.243 5 5 5 5-2.243 
                   5-5-2.243-5-5-5zM27 32a1 1 0 0 
                   1-1-1v-6.115a6.95 6.95 0 0 
                   0-6.942-6.943h-6.116A6.95 6.95 0 
                   0 0 6 24.885V31a1 1 0 1 1-2 
                   0v-6.115c0-4.93 4.012-8.943 
                   8.942-8.943h6.116c4.93 0 8.942 
                   4.012 8.943 8.943V31a1 1 0 0 
                   1-1 1z"/>
            </svg>
        </label>

        <div class="dropdown-menu">
            <a href="disconnect.php">Se déconnecter</a>
        </div>
    </div>
</nav>
