--
-- Fichier 2/2 : APPRESTO_data.sql
-- Contient uniquement les donn�es initiales (INSERT INTO).
--

USE `APPRESTO`;

--
-- D�chargement des donn�es de la table `Etat`
--

INSERT INTO `Etat` (`id_etat`, `lib_etat`) VALUES
(1, 'Initialis�e'),
(2, 'Finalis�e'),
(3, 'Calcul�e'),
(4, 'En attente'),
(5, 'Abandonn�e'),
(6, 'En pr�paration'),
(7, 'Pr�te'),
(8, 'Servie');

--
-- D�chargement des donn�es de la table `Produit`
--

INSERT INTO `Produit` (`id_produit`, `lib_produit`, `prix_unitaire_HT`) VALUES
(1, 'Maf�', 19.99),
(2, 'Attiek�', 12.99),
(3, 'Foutou', 15.99),
(4, 'Poulet Yassa', 22.99),
(5, 'Alloco Poulet', 17.99),
(6, 'Riz tikka massala', 14.99),
(7, 'Tiep Poisson', 15.99),
(8, 'Bissap', 8.99),
(9, 'Thiakry', 9.99),
(10, 'Malva Pudding', 8.99),
(11, 'Kachumbari', 9.99),
(12, 'Soupe d\'arachide', 8.99);

--
-- D�chargement des donn�es de la table `Utilisateur`
--

INSERT INTO `Utilisateur` (`id_utilisateur`, `identifiant`, `mot_de_passe`, `email`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com');

COMMIT;