<?php
echo '<footer class="footer">';
echo '<p>';
echo ' RestoWEb - &copy; 2024 Le Palais Des Saveurs - Tous droits réservés - ';
echo '<span style="color: orange;">BTS SIO</span>';
echo '<span style="color: orange;"></span>';
echo '</p>';
echo '</footer>';

?>